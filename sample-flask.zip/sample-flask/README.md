python -m pip install flask
virtualenv -p python3 flask-getting-started
export FLASK_APP=flashcards.py  
export FLASK_ENV=development  
flask run or python -m flask run

Jinja templates generates text files and we are using it to generate HTML file
Jinja fills up this template with values and sends the HTML to browser.
Jinja looks at the file as a text file
We can write logics in Jinja template
{{ }} is called placeholder

Model Template View === MVC
browser send request to server
server looks up url_map and calls appropriate view function - controller
View function can call db - model
View function send data to Jinja2 and gets back html to controller- View
Controller sends back to browser

Parameters in url:
@app.route('/book/<int:index>')

404:
except exception:
abort(404) -> abort is from flask

dynamic linking:
url_for looks up for url in the passed in view function.
here details is the view function
index is the param to th view function
{{url_for('details', index=index+1)}}

if:
{{% if condition %}}
{{% else %}}
{{% endif %}}

for:
{{% for n in nums_arr}}
{{% endfor %}}

REST API:
sending JSON response using jsonify

DEPLOYMENT:
ssh to an instance
clone the project
pip3 install -r requirements.txt
sudo apt install gunicorn3 python3
gunicorn3 flashcard.py -D runs background

NGINX config:
/etc/nginx/sites-available/default
Add the code:
server {
listen 80;
server_name example.org;
access_log /var/log/nginx/example.log;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

}
sudo service nginx restart
