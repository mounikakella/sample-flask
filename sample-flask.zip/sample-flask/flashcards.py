from flask import Flask, render_template, abort, jsonify, request, redirect, url_for

app = Flask(__name__) # passing in name of the module

@app.route("/") # decorator converted a function into view function
def home():
    return "Home"

@app.route("/test") # decorator converted view function
def test():
    return "Test Page"

counter = 0
@app.route("/count")
def count():
    global counter
    counter = counter + 1
    return "counter is " + str(counter)

@app.route('/welcome')
def welcome():
    return render_template('welcome.html', name="mounika")

@app.route('/details')
def details():
    details_dict = {'fname': 'Bob', 'lname': 'Bayor' }
    return render_template('details.html', details=details_dict)

@app.route('/details/<int:index>')
def param_details(index):
    details_arr= [{'fname': 'Adam', 'lname': 'Bayor' }, {'fname': 'Bob', 'lname': 'Bayor' }]
    try:
        return render_template('details.html', details=details_arr[index], index=index)
    except IndexError:
        abort(404)


@app.route('/all-details')
def all_details():
    details_arr= [{'fname': 'Adam', 'lname': 'Bayor' }, {'fname': 'Bob', 'lname': 'Bayor' }]
    return jsonify(details_arr)


@app.route('/add-details', methods=['POST', 'GET'])
def add_details():
    if request.method == "POST":
        fname = request.form['fname']
        lname = request.form['lname']
    # save into db here and redirect
        return redirect(url_for('home'))
    else:
        return render_template('add_details.html')



